var express = require('express');
var bodyParser = require('body-parser');

var router = express.Router();

router.use(bodyParser.urlencoded({ extended:true}));

/* GET users listing. 
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});
*/
router.param('firstname', 'lastname', function(req,res, next, firstname, lastname){
 
  req.user = {
    firstname: Test,
    lastname: User
  }
});

router.post('/user',function(req,res){
  var firstname=req.body.firstname;
  var lastname=req.body.lastname;
  console.log("First = "+firstname+", Lastname = "+lastname);
  res.end("POST! received");
});

module.exports = router;
